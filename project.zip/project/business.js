const db = require('./database');
const crypto = require('crypto');

// ===== USER REGISTRATION & VERIFICATION ===== //
async function registerUser(name, email, password, program) {
    const existingUser = await db.getUserByEmail(email);
    if (existingUser) throw new Error("User already exists");

    const hashedPassword = crypto.createHash('sha256').update(password).digest('hex');
    let correted_email = email.toLowerCase().trim(); // Normalize email to lowercase

    const newUser = {
        name,
        correted_email,
        type: 'basic',  // Default user type
        password: hashedPassword,
        program,
        isVerified: false,  // New users are unverified by default
        createdAt: new Date(),
        resetKey: null,
        resetExpiry: null
    };

    const user = await db.addUser(newUser);
    await startVerification(email);  // Automatically trigger verification
    
    return user;
}

async function startVerification(email) {
    const token = Math.random().toString(36).slice(2, 12); // 10-char token
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours
    
    await db.addVerificationToken(email, token, expiresAt);
    
    console.log(`\n=== EMAIL VERIFICATION (SIMULATED) ===`);
    console.log(`To: ${email}`);
    console.log(`Token: ${token}`);
    console.log(`Expires: ${expiresAt}`);
    console.log(`Click the link to verify: http://localhost:8000/verify?email=${email}&token=${token}`);
    console.log(`======================================\n`);
    
    return { token, expiresAt };
}

async function completeVerification(email, token) {
    const isValid = await db.verifyToken(email, token);
    if (!isValid) throw new Error("Invalid or expired token");
    return true;
}

// ===== AUTHENTICATION ===== //
async function loginUser(userName, Password) {
    const details = await db.getUserByName(userName);
    let pshach = crypto.createHash('sha256').update(Password).digest('hex');

    if (details == undefined || details.password != pshach) {
        return undefined;
    }
    
    let sessionKey = crypto.randomUUID();
    let sd = {
        key: sessionKey,
        expiry: new Date(Date.now() + 1000 * 60 * 5),
        data: {
            username: details.name,
            type: details.type
        }
    };
    await db.addSession(sd);
    return sd;
}

// ===== PASSWORD RESET ===== //
async function checkEmail(email) {
    if (!email || !email.includes("@udst.edu.qa")) return false;
    const user = await db.getUserByEmail(email);
    return !!user;
}

async function createResetPassword(email) {
    const user = await db.getUserByEmail(email);
    if (!user) throw new Error("Email not found");
    const resetKey = Math.random().toString(36).substr(2, 8);
    const resetExpiry = new Date(Date.now() + 1000 * 60 * 30); // 30 minutes
    await db.updateResetPassword(email, resetKey, resetExpiry);
    return { resetKey, resetExpiry };
}

async function checkResetKey(resetKey) {
    const resetEntry = await db.getResetPasswordEntry(resetKey);
    if (!resetEntry || resetEntry.resetExpiry < new Date()) return false;
    return true;
}

async function resetPassword(email, newPassword) {
    const user = await db.getUserByEmail(email);
    if (!user) throw new Error("User not found");
    let pshach = crypto.createHash('sha256').update(newPassword).digest('hex');
    return db.updateUserPassword(email, pshach);
}

// ===== SESSIONS ===== //
async function getSessionData(sessionKey) {
    const session = await db.getSessionByKey(sessionKey);
    return session ? session.data.type : undefined;
}

async function terminateSession(sessionKey) {
    const session = await db.getSessionByKey(sessionKey);
    if (!session) throw new Error("Session not found");
    return db.deleteSession(sessionKey);
}

async function getDateByKey(key) {
    let data = await db.getResetPasswordEntry(key);
    return {
        resetKey: data.resetKey,
        resetExpiry: data.resetExpiry,
        email: data.email
    };
}

// Add this function to handle request creation
async function addRequest(requestData) {
    try {
        const db = await connectDatabase();
        // Add additional validation if needed
        if (!requestData.studentId || !requestData.request_type || !requestData.description) {
            throw new Error("Missing required fields");
        }
        
        // Insert the request into database
        const result = await db.collection('forms').insertOne(requestData);
        
        console.log(`New request created: ${result.insertedId}`);
        return result;
    } catch (error) {
        console.error("Error adding request:", error);
        throw error;
    }
}

// Add this function to get user by username
async function getUserByName(username) {
    try {
        const db = await connectDatabase();
        return await db.collection('UserAccounts').findOne({ name: username });
    } catch (error) {
        console.error("Error fetching user:", error);
        throw error;
    }
}

// Add this function to get session by key
async function getSessionByKey(key) {
    try {
        const db = await connectDatabase();
        return await db.collection('SessionData').findOne({ key: key });
    } catch (error) {
        console.error("Error fetching session:", error);
        throw error;
    }
}


// ===== EXPORTS ===== //
module.exports = {
    // Auth
    registerUser,
    loginUser,
    // Verification
    startVerification,
    completeVerification,
    // Password Reset
    checkEmail,
    createResetPassword,
    checkResetKey,
    resetPassword,
    // Sessions
    terminateSession,
    getSessionData,
    getDateByKey,
    getUserByName,
    getSessionByKey
};