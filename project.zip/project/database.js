const mongodb = require('mongodb');

let client;
let db;

// Database connection
async function connectDatabase() {
    if (!client) {
        client = new mongodb.MongoClient('mongodb+srv://60102562:12class34@cluster0.ps18e.mongodb.net/');
        await client.connect();
        db = client.db('project');
    }
    return db;
}

// ===== USER FUNCTIONS ===== //
async function addUser(userData) {
    const db = await connectDatabase();
    return db.collection('UserAccounts').insertOne(userData);
}

async function getUserByEmail(email) {
    const db = await connectDatabase();
    return db.collection('UserAccounts').findOne({ email: email });
}

async function getUserByName(name) {
    const db = await connectDatabase();
    return db.collection('UserAccounts').findOne({ name: name });
}

async function updateUserPassword(email, newPassword) {
    const db = await connectDatabase();
    let user = db.collection('UserAccounts');
    user.updateOne({ email }, { $set: { resetExpiry: "" } });
    user.updateOne({ email }, { $set: { resetKey: "" } });
    return user.updateOne({ email }, { $set: { password: newPassword } });
}

// ===== PASSWORD RESET FUNCTIONS ===== //
async function updateResetPassword(email, resetKey, resetExpiry) {
    const db = await connectDatabase();
    return db.collection('UserAccounts').updateOne(
        { email }, 
        { $set: { resetKey, resetExpiry } }
    );
}

async function getResetPasswordEntry(resetKey) {
    const db = await connectDatabase();
    return db.collection('UserAccounts').findOne({ resetKey });
}

// ===== SESSION FUNCTIONS ===== //
async function addSession(sessionData) {
    const db = await connectDatabase();
    return db.collection('SessionData').insertOne(sessionData);
}

async function getSessionByKey(sessionKey) {
    const db = await connectDatabase();
    return db.collection('SessionData').findOne({ key: sessionKey });
}

async function deleteSession(sessionKey) {
    const db = await connectDatabase();
    return db.collection('SessionData').deleteOne({ key: sessionKey });
}

// ===== REQUEST FUNCTIONS ===== //
async function addRequest(requestData) {
    const db = await connectDatabase();
    requestData.status = 'pending';
    requestData.createdAt = new Date();
    return db.collection('forms').insertOne(requestData);
}

async function cancelRequest(requestId) {
    const db = await connectDatabase();
    return db.collection('forms').updateOne(
        { _id: new mongodb.ObjectId(requestId) },
        { $set: { status: 'cancelled', cancelledAt: new Date() } }
    );
}

async function getRequestsByStudent(studentId, semester) {
    const db = await connectDatabase();
    const query = { studentId, semester };
    return db.collection('forms').find(query).toArray();
}

async function processRequest(requestId, status) {
    const db = await connectDatabase();
    const result = await db.collection('forms').updateOne(
        { _id: new mongodb.ObjectId(requestId) },
        { $set: { status, processedAt: new Date() } }
    );
    if (result.modifiedCount > 0) {
        const request = await db.collection('forms').findOne({ _id: new mongodb.ObjectId(requestId) });
        console.log(`Email notification for request ${requestId}: Status changed to ${status}`);
    }
    return result;
}

// ===== GET USER REQUESTS ===== //


async function getSessionByKey(sessionKey) {
    const db = await connectDatabase();
    return db.collection('SessionData').findOne({ key: sessionKey });
}

async function getUserByName(name) {
    const db = await connectDatabase();
    return db.collection('UserAccounts').findOne({ name: name });
}

// ===== NEW VERIFICATION FUNCTIONS ===== //
async function addVerificationToken(email, token, expiresAt) {
    const db = await connectDatabase();
    return db.collection('VerificationTokens').insertOne({
        email,
        token,
        expiresAt,
        createdAt: new Date()
    });
}

async function verifyToken(email, token) {
    const db = await connectDatabase();
    const record = await db.collection('VerificationTokens').findOne({
        email,
        token,
        expiresAt: { $gt: new Date() }
    });
    
    if (record) {
        await db.collection('UserAccounts').updateOne(
            { email },
            { $set: { isVerified: true } }
        );
        await db.collection('VerificationTokens').deleteOne({ _id: record._id });
        return true;
    }
    return false;
}

module.exports = {
    // User
    addUser,
    getUserByEmail,
    getUserByName,
    updateUserPassword,
    // Password Reset
    updateResetPassword,
    getResetPasswordEntry,
    // Sessions
    addSession,
    getSessionByKey,
    deleteSession,
    // Requests
    addRequest,
    cancelRequest,
    getRequestsByStudent,
    processRequest,
    // Verification
    addVerificationToken,
    verifyToken
};